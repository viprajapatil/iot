/**************************************************************************//**
 * @file
 * @brief Simple LED Blink Demo for EFM32GG_STK3700
 * @version 3.20.5
 ******************************************************************************
 * @section License
 * <b>(C) Copyright 2014 Silicon Labs, http://www.silabs.com</b>
 *******************************************************************************
 *
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 *
 ******************************************************************************/

#include "em_device.h"
#include <stdint.h>
#include "em_chip.h"
#include "em_i2c.h"
#include "i2cdrv.h"
#include "em_cmu.h"
#include "bsp.h"
#include "bq27510.h"


/* Defines*/
#define RTC_MIN_TIMEOUT                32000

static void gpioSetup(void);

/**************************************************************************//**
 * @brief  Main function
 *****************************************************************************/
int main(void) {

  I2C_Init_TypeDef i2cInit = I2C_INIT_DEFAULT;
  bool bq27510_status;
  uint32_t         socData;

  /* Misc initalizations. */
  gpioSetup();

  /* Chip errata */
  CHIP_Init();

  /* Initialize I2C driver, using standard rate. */
//  CMU_ClockEnable(cmuClock_I2C0, true); think this happens in I2CDRV_Init

  I2CDRV_Init(&i2cInit);
  bq27510_status = bq27510_Detect(I2C0, BQ27510_ADDR);
  bq27510_MeasureStateOfCharge(I2C0, BQ27510_ADDR, socData);





  /* Infinite loop */
  while (1) {
  }
}

/**************************************************************************//**
 * @brief Setup GPIO
 *****************************************************************************/
static void gpioSetup(void)
{
  /* Enable GPIO clock. */
  CMU_ClockEnable(cmuClock_GPIO, true);

}
