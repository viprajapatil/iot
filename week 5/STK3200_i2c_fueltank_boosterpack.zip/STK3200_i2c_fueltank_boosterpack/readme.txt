
Board:  Silicon Labs EFM32ZG_STK3200 Starter Kit
Device: EFM32ZG222F32
