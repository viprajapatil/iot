/*
 * bq27510.c
 *
 *  Created on: Nov 23, 2014
 *      Author: Jan
 */


#include "bq27510.h"
#include "i2cdrv.h"

/*******************************************************************************
 *******************************   DEFINES   ***********************************
 ******************************************************************************/

/** @cond DO_NOT_INCLUDE_WITH_DOXYGEN */


/** bq27510 Read SOC Command */
#define bq27510CMD_SOC_LSB   0x20
#define bq27510CMD_SOC_MSB   0x21

/** bq27510 Read ID */
#define bq27510CMD_CNTL_LSB  0x00
#define bq27510CMD_CNTL_MSB  0x01

/** @endcond */

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/


/**************************************************************************//**
 * @brief
  *  Reads data from the bq27510 fuel gauge.
 * @param[in] i2c
 *   The I2C peripheral to use (not used).
 * @param[in] addr
 *   The I2C address of the sensor.
 * @param[out] data
 *   The data read from the sensor.
 * @param[in] command
 *   The command to send to device. See the \#define's for details.
 * @return
 *   Returns number of bytes read on success. Otherwise returns error codes
 *   based on the I2CDRV.
 *****************************************************************************/
static int bq27510_Measure(I2C_TypeDef *i2c, uint8_t addr, uint32_t *data,
                          uint8_t command)
{
  I2C_TransferSeq_TypeDef    seq;
  I2C_TransferReturn_TypeDef ret;
  uint8_t                    i2c_read_data[2];
  uint8_t                    i2c_write_data[1];

  /* Unused parameter */
  (void) i2c;

  seq.addr  = addr;
  seq.flags = I2C_FLAG_WRITE_READ;
  /* Select command to issue */
  i2c_write_data[0] = command;
  seq.buf[0].data   = i2c_write_data;
  seq.buf[0].len    = 1;
  /* Select location/length of data to be read */
  seq.buf[1].data = i2c_read_data;
  seq.buf[1].len  = 2;

  ret = I2CDRV_Transfer(&seq);

  if (ret != i2cTransferDone)
  {
    *data = 0;
    return((int) ret);
  }

  *data = ((uint32_t) i2c_read_data[0] << 8) + (i2c_read_data[1] & 0xfc);

  return((int) 2);
}


/**************************************************************************//**
 * @brief
  *  Reads state of charge from a bq27510 fuel gauge.
 * @param[in] i2c
 *   The I2C peripheral to use.
 * @param[in] addr
 *   The I2C address of the sensor.
 * @param[out] socData
 *   The State of Charge in percent
 * @return
 *   Returns zero on OK, non-zero otherwise.
 *****************************************************************************/
int bq27510_MeasureStateOfCharge(I2C_TypeDef *i2c, uint8_t addr, uint32_t *socData) {
  int ret = bq27510_Measure(i2c, addr, socData, bq27510CMD_SOC_LSB);

  if (ret != 2) {
    return -1;
  }

  return 0;
}

/**************************************************************************//**
 * @brief
 *   Checks if a bq27510 is present on the I2C bus or not.
 * @param[in] i2c
 *   The I2C peripheral to use (Not used).
 * @param[in] addr
 *   The I2C address to probe.
 * @return
 *   True if a bq27510 is detected, false otherwise.
 *****************************************************************************/
bool bq27510_Detect(I2C_TypeDef *i2c, uint8_t addr)
{
  return(true);
}

