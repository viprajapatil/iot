/***********************************************************************************************//**
 * \file   main.c
 * \brief  Silicon Labs Empty Example Project
 *
 * This example demonstrates the bare minimum needed for a Blue Gecko C application
 * that allows Over-the-Air Device Firmware Upgrading (OTA DFU). The application
 * starts advertising after boot and restarts advertising after a connection is closed.
 ***************************************************************************************************
 * <b> (C) Copyright 2016 Silicon Labs, http://www.silabs.com</b>
 ***************************************************************************************************
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 * *************************************************************************************************
 Sleep routines were taken for Silicon labs
 **************************************************************************************************/

/* Board headers */
#include "boards.h"
#include "ble-configuration.h"
#include "board_features.h"
#include "adcsetup.h"
/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"
#include "aat.h"

/* Libraries containing default Gecko configuration values */
#include "em_emu.h"
#include "em_cmu.h"
#ifdef FEATURE_BOARD_DETECTED
#include "bspconfig.h"
#include "pti.h"
#endif

/* Device initialization header */
#include "InitDevice.h"

#ifdef FEATURE_SPI_FLASH
#include "em_usart.h"
#include "mx25flash_spi.h"
#endif /* FEATURE_SPI_FLASH */

/***********************************************************************************************//**
 * @addtogroup Application
 * @{
 **************************************************************************************************/

/***********************************************************************************************//**
 * @addtogroup app
 * @{
 **************************************************************************************************/

#ifndef MAX_CONNECTIONS
#define MAX_CONNECTIONS 4
#endif
uint8_t bluetooth_stack_heap[DEFAULT_BLUETOOTH_HEAP(MAX_CONNECTIONS)];

#ifdef FEATURE_PTI_SUPPORT
static const RADIO_PTIInit_t ptiInit = RADIO_PTI_INIT;
#endif

/* Gecko configuration parameters (see gecko_configuration.h) */
static const gecko_configuration_t config = {
  .config_flags = 0,
  .sleep.flags = SLEEP_FLAGS_DEEP_SLEEP_ENABLE,
  .bluetooth.max_connections = MAX_CONNECTIONS,
  .bluetooth.heap = bluetooth_stack_heap,
  .bluetooth.heap_size = sizeof(bluetooth_stack_heap),
  .bluetooth.sleep_clock_accuracy = 100, // ppm
  .gattdb = &bg_gattdb_data,
  .ota.flags = 0,
  .ota.device_name_len = 3,
  .ota.device_name_ptr = "OTA",
  #ifdef FEATURE_PTI_SUPPORT
  .pti = &ptiInit,
  #endif
};

/* Flag for indicating DFU Reset must be performed */
uint8_t boot_to_dfu = 0;

//***********************************************************************************
// Include files
//***********************************************************************************
#include <stdint.h>
#include <stdbool.h>
#include "em_device.h"
#include "em_chip.h"
#include "main.h"
#include "gpio.h"
#include "cmu.h"
#include "em_cmu.h"
#include "sleep.h"
#include "letimer0.h"
#include "adcsetup.h"
#include "timer0.h"
#include "i2c.h"
#include "usart.h"
#include "infrastructure.h"

//***********************************************************************************
// defined files
//***********************************************************************************
#define gecko_tx_min -260
#define gecko_tx_max  80
#define bt_current_tx_power
#define bt_min_interval 60
#define bt_max_interval 60
#define bt_slave_latency 4
#define bt_timeout 200
#define UINT32_TO_BITSTREAM(p, n)   { *(p)++ = (uint8_t)(n); *(p)++ = (uint8_t)((n) >> 8); \
                                      *(p)++ = (uint8_t)((n) >> 16); *(p)++ = (uint8_t)((n) >> 24); }

volatile bool bounce;
volatile int16_t tempValue;         /* Stores the Temperature data read from the RHT sensor. */
int8_t connection;


//***********************************************************************************
// global variables
//***********************************************************************************
int8_t temp_evt;
//volatile int external_event_status;
uint32_t temperature;   /* Stores the temperature data read from the sensor in the correct format */
bool temp_sense = false;
//***********************************************************************************
// function prototypes
//***********************************************************************************


//***********************************************************************************
// functions
//***********************************************************************************


//***********************************************************************************
// main
//***********************************************************************************
void temperatureMeasure()
{
  uint8_t Buffer[5];      /* Stores the temperature data in the Health Thermometer (HTM) format. */
  uint8_t flags = 0x00;   /* HTM flags set as 0 for Celsius, no time stamp and no temperature type. */

  uint8_t *p = Buffer;    /* Pointer to HTM temperature buffer needed for converting values to bitstream. */

  /* Convert flags to bitstream and append them in the HTM temperature data buffer (htmTempBuffer) */
  UINT8_TO_BITSTREAM(p, flags);
  temperature = getTemperatureFromSi7021();

//    /* Convert temperature to bitstream and place it in the HTM temperature data buffer (htmTempBuffer) */
    UINT32_TO_BITSTREAM(p, temperature);
    /* Send indication of the temperature in htmTempBuffer to all "listening" clients.
     * This enables the Health Thermometer in the Blue Gecko app to display the temperature.
     *  0xFF as connection ID will send indications to all connections. */
    gecko_cmd_gatt_server_send_characteristic_notification(0xFF, gattdb_temp_measurement, 5, Buffer);
  //}
}

/**
 * @brief  Main function
 */
int main(void)
{
    CHIP_Init();
	#ifdef FEATURE_SPI_FLASH
	  /* Put the SPI flash into Deep Power Down mode for those radio boards where it is available */

    MX25_init();
	  MX25_DP();
	  /* We must disable SPI communication */
	  USART_Reset(USART1);

	#endif /* FEATURE_SPI_FLASH */

  /* Initialize peripherals */
	  enter_DefaultMode_from_RESET();

  /* Initialize stack */
  	 gecko_init(&config);

	/* Initialize clocks */
	cmu_init();

	/* Initialize GPIO */
	gpio_init();
	LETIMER0_init();
	adc_init();
	TIMER0_init();
	usart_setup();
	//BMA280_normal();
	BMA280_init();
	I2C_init();
	int8_t rssi = 0;

	while(1)
	{
	//sleep();
	/* Event pointer for handling events */
		struct gecko_cmd_packet* evt;

		/* Check for stack event. */
		evt = gecko_wait_event();

		/* Handle events */
		switch (BGLIB_MSG_ID(evt->header)) {
		/* This boot event is generated when the system boots up after reset.
		 * Here the system is set to start advertising immediately after boot procedure. */
			case gecko_evt_system_boot_id:
				/* Set advertising parameters. 100ms advertisement interval. All channels used.
		         * The first two parameters are minimum and maximum advertising interval, both in
		         * units of (milliseconds * 1.6). The third parameter '7' sets advertising on all channels. */
		        gecko_cmd_le_gap_set_adv_parameters(800, 800, 7);

		        /* Start general advertising and enable connections. */
		        gecko_cmd_le_gap_set_mode(le_gap_general_discoverable, le_gap_undirected_connectable);
		        //gecko_cmd_system_set_tx_power(0);
		        break;

		    case gecko_evt_le_connection_closed_id:
		    	/* Check if need to boot to dfu mode */
		        if (boot_to_dfu) {
		        /* Enter to DFU OTA mode */
		        gecko_cmd_system_reset(2);
		        } else {
		        /* Restart advertising after client has disconnected */
		        	gecko_cmd_system_set_tx_power(0);
		          gecko_cmd_le_gap_set_mode(le_gap_general_discoverable, le_gap_undirected_connectable);
		        }
		        break;

		    case gecko_evt_le_connection_opened_id:
		         				  connection = evt->data.evt_le_connection_opened.connection;
		         				gecko_cmd_le_connection_set_parameters(evt->data.evt_le_connection_opened.connection, 0x003C, 0x003C, 0x0004,0x0258);
		   //Getting the connection and using it for setting rssi event
		         				  break;

		    case gecko_evt_gatt_server_characteristic_status_id:
		    	if (evt-> data.evt_gatt_server_characteristic_status.status_flags == gatt_server_confirmation)
		    	{
		    		gecko_cmd_le_connection_get_rssi(evt-> data.evt_gatt_server_characteristic_status.connection);
		    	}
		    	break;

		    case gecko_evt_le_connection_rssi_id:

		    	rssi = evt-> data.evt_le_connection_rssi.rssi;

		    	if (rssi > -35)
		    	{gecko_cmd_system_set_tx_power(gecko_tx_min);}
		    	else if (rssi < -35 && rssi > -45)
		    	{gecko_cmd_system_set_tx_power(-200);}
		    	else if (rssi < -45 && rssi > -55)
		    	{gecko_cmd_system_set_tx_power(-150);}
		    	else if (rssi < -55 && rssi > -65)
		    	{gecko_cmd_system_set_tx_power(-50);}
		    	else if (rssi < -65 && rssi > -75)
		    	{gecko_cmd_system_set_tx_power(0);}
		    	else if (rssi < -75 && rssi > -85)
		    	{gecko_cmd_system_set_tx_power(50);}
		    	else
		    	{gecko_cmd_system_set_tx_power(gecko_tx_max);}


		    	break;

		    case gecko_evt_system_external_signal_id:
		    	temp_evt = 0;

		    	if (((evt->data.evt_system_external_signal.extsignals) & letimer_ext_evt_uf) !=0)
		    	{
		    		//LETIMER_IntClear(LETIMER0, LETIMER_IF_COMP0);
		    		if (temp_sense)
		    		{
		    			temperatureMeasure();
		    		}
		    		//temperatureMeasure();

		    	    temp_evt |= letimer_ext_evt_uf;

		    	}
		    	if (((evt->data.evt_system_external_signal.extsignals) & bma_evt_enable) !=0)
		    	{

		    		CORE_AtomicDisableIrq();
		    		lpmOn();
		    		//GPIO_PinOutSet(LED0_port, LED0_pin);
		    		BMA280_RegisterWrite(0x16, (0x00 << 5)  | (0x01 << 4));		//enabling double tap Interrupt
		    		BMA280_RegisterRead(0x16);
		    		BMA280_RegisterWrite(0x19, 0x01 << 4); 	//mapping INT1 to double TAP
		    		BMA280_RegisterRead(0x19);
		    		g_sensor= true;
		    		temp_sense = true;
		    		temp_evt |= bma_evt_enable;
		    		CORE_AtomicEnableIrq();
		    	}
		    	if (((evt->data.evt_system_external_signal.extsignals) & bma_evt_disable) !=0)
		    	{
		    		CORE_AtomicDisableIrq();

					lpmOff();
					//GPIO_PinOutClear(LED0_port, LED0_pin);
					BMA280_RegisterWrite(0x16, (0x01 << 5) | (0x00 << 4) );		//enabling single tap Interrupt
					BMA280_RegisterRead(0x16);
					BMA280_RegisterWrite(0x19, 0x01 << 5); 	//mapping INT1 to single TAP
					BMA280_RegisterRead(0x19);
					g_sensor = false;
					temp_sense = false;
		    		temp_evt |= bma_evt_disable;

		    		CORE_AtomicEnableIrq();
		    	}
		    	if (((evt->data.evt_system_external_signal.extsignals) & adc_evt_north) !=0)
		    	{//GPIO_PinOutSet(LED1_port, LED1_pin);
		    		BMA280_normal();
		    		adcWindowout();
		    		bounce = false;
		    		temp_evt |= adc_evt_north;
		    	}
		    	if (((evt->data.evt_system_external_signal.extsignals) & adc_evt_south) !=0)
		    	{
		    		//GPIO_PinOutSet(LED0_port, LED0_pin);
		    		BMA280_suspend();
		    		if (temperature > tempSetValue)
		    		{
		    			GPIO_PinOutClear(LED1_port, LED1_pin);
		    		}
		    		adcWindowout();
		    		bounce = false;
		    		temp_evt |= adc_evt_south;
		    	}
		    	if (((evt->data.evt_system_external_signal.extsignals) & adc_evt_west) !=0)
		    	{
		    		tempSetValue -= 5;
		    		adcWindowout();
		    		bounce = false;
		    		temp_evt |= adc_evt_west;
		    	}
		    	if (((evt->data.evt_system_external_signal.extsignals) & adc_evt_east) !=0)
		    	{
		    		tempSetValue += 5;
		    		if (temperature < tempSetValue)
		    				    		{
		    				    			GPIO_PinOutSet(LED1_port, LED1_pin);
		    				    		}
		    		adcWindowout();
		    		bounce = false;
		    		temp_evt |= adc_evt_east;
		    	}

		    	CORE_AtomicDisableIrq();
		    	external_event_status &= ~(temp_evt);
		    	CORE_AtomicEnableIrq();
		    	break;

		    default:
		    	break;


		  }
		}
	}
void LETIMER0_IRQHandler(void)
{
	CORE_AtomicDisableIrq();

	  if ( ((LETIMER0->IF) & (LETIMER_IF_COMP0)))
	  {
		  /*GPIO_PinOutSet(LED0_port, LED0_pin);*/
		  LETIMER_IntClear(LETIMER0, LETIMER_IF_COMP0);
//
//		  //if(tsensor)
//		  if(GPIO_PinOutGet(gpioPortD,9))
//		  {
//			  int newtemp = getTemperatureFromSi7021();
//			  			  if (newtemp < tempSetValue)
//			  			  {
//			  				  GPIO_PinOutSet(LED1_port, LED1_pin);
//			  			  }
//		  }

	  }

	 /* else if ( ((LETIMER0->IF) & (LETIMER_IF_COMP1)))
	  {
		  GPIO_PinOutClear(LED0_port, LED0_pin);
		   LETIMER_IntClear(LETIMER0, LETIMER_IF_COMP1);

	  }
	  else
	  {

	  }
	  */
	  external_event_status |= letimer_ext_evt_uf;
	 gecko_external_signal(external_event_status);
		gecko_cmd_le_connection_get_rssi(connection);


	 CORE_AtomicEnableIrq();



}




/** @} (end addtogroup app) */
/** @} (end addtogroup Application) */
