/*
 * usart.h
 *
 *  Created on: Sep 28, 2017
 *      Author: Vipraja
 */

#ifndef SRC_USART_H_
#define SRC_USART_H_

#define bma_evt_disable 32
#define bma_evt_enable 64

void usart_init();
void BMA280_RegisterWrite(uint8_t, uint8_t);
uint8_t BMA280_RegisterRead(uint8_t);
void BMA280_init();
void enablegpio();
void BMA280_normal();
void BMA280_suspend();
void usart_setup();
extern volatile int external_event_status;

#endif /* SRC_USART_H_ */
