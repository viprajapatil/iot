/*
 * adcsetup.h
 *
 *  Created on: Sep 20, 2017
 *      Author: Vipraja
 */
#include <stdbool.h>

#ifndef SRC_ADCSETUP_H_
#define SRC_ADCSETUP_H_

#define adc_evt_north  0x02
#define adc_evt_south  0x04
#define adc_evt_west  8
#define adc_evt_east  16
volatile int external_event_status;

void adc_init(void);
void adcWindow(void);
void adcWindowout(void);
void debounce(void);
void ADC0_IRQHandler(void);


#endif /* SRC_ADCSETUP_H_ */
