#ifndef BG_GATTDB_H
#define BG_GATTDB_H

#include "bg_gattdb_def.h"

extern const struct bg_gattdb_def bg_gattdb_data;

#define secret_string                          15
#define accm_data                              18

#endif
